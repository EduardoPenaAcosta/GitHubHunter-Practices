package com.zooLaOrotava.Animals.Birds;

public class BlackBird extends Bird{
    public BlackBird(String name, int age, String sex, double altitude, String color) {
        super(name, age, sex, altitude, color);
    }


    public String returnSex(String sex) {
        return sex;
    }
}

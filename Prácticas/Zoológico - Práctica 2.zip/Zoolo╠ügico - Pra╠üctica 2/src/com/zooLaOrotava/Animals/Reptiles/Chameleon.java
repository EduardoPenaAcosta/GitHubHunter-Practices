package com.zooLaOrotava.Animals.Reptiles;

public class Chameleon extends Reptile{
    public Chameleon(String name, int age, String sex, double CorpTemp, String Color, double Speed) {
        super(name, age, sex, CorpTemp, Color, Speed);
    }

}

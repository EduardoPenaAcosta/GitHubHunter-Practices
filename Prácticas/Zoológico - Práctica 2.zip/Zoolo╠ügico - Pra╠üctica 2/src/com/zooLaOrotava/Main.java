package com.zooLaOrotava;

import com.zooLaOrotava.Zoo.MainZoo;

public class Main {

    public static void main(String[] args) {

        new MainZoo(6,12);
        MainZoo.main(null);

    }
}
